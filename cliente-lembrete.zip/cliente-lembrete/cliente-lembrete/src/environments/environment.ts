export const environment = {
  production: false,
  lembretesApiUrl: 'https://deviup.com.br:3001/api'
};
