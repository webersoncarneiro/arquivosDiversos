export const environment = {
  production: true,
  lembretesApiUrl: 'https://deviup.com.br:3001/api'
};
